<?php
// ─────────────────────────────────────────────────────────
//  config.php  –  RecipeShare configuration
//  Copy this file and rename it; never commit real creds.
// ─────────────────────────────────────────────────────────

// ── Database ──────────────────────────────────────────────
define('DB_HOST', 'localhost');
define('DB_PORT', '3306');
define('DB_NAME', 'recipeshare');
define('DB_USER', 'root');          // ← change in production
define('DB_PASS', '');              // ← change in production
define('DB_CHARSET', 'utf8mb4');

// ── Session tokens ────────────────────────────────────────
define('SESSION_TTL_HOURS', 72);    // token expiry

// ── Password hashing ──────────────────────────────────────
define('BCRYPT_COST', 12);

// ── CORS (set to your frontend origin in production) ──────
define('ALLOW_ORIGIN', '*');        // e.g. 'https://recipeshare.com'

// ── Pagination defaults ───────────────────────────────────
define('DEFAULT_PAGE_SIZE', 12);
