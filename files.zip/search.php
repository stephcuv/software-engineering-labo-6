<?php
// ─────────────────────────────────────────────────────────
//  api/search.php  –  Search & Filter Module
//
//  GET /api/search.php
//      ?q=          full-text search (title, description, tags)
//      &tag=        exact tag match
//      &category=   exact category match
//      &min_rating= minimum avg_rating (1–5)
//      &difficulty= Easy | Medium | Hard
//      &max_time=   max total time in minutes (prep+cook)
//      &page=       page number (default 1)
//      &per_page=   results per page (default 12, max 50)
//      &sort=       newest | rating | time  (default: newest)
//
//  Returns:
//    { success, data: { recipes[], total, page, per_page, pages } }
// ─────────────────────────────────────────────────────────
require_once __DIR__ . '/../helpers.php';

send_headers();

if ($_SERVER['REQUEST_METHOD'] !== 'GET') json_err('GET only.', 405);

// ── Parse & sanitise params ───────────────────────────────
$q          = sanitise($_GET['q']          ?? '', 200);
$tag        = sanitise($_GET['tag']        ?? '', 100);
$category   = sanitise($_GET['category']   ?? '', 100);
$minRating  = (float) ($_GET['min_rating'] ?? 0);
$difficulty = sanitise($_GET['difficulty'] ?? '', 10);
$maxTime    = (int)   ($_GET['max_time']   ?? 0);
$page       = max(1, (int) ($_GET['page']    ?? 1));
$perPage    = min(50, max(1, (int) ($_GET['per_page'] ?? DEFAULT_PAGE_SIZE)));
$sort       = in_array($_GET['sort'] ?? '', ['newest','rating','time'])
              ? $_GET['sort'] : 'newest';

// ── Build WHERE clauses ───────────────────────────────────
$where  = ['r.status = "published"'];
$params = [];

// Full-text search
if ($q !== '') {
    $where[]  = 'MATCH(r.title, r.description, r.tags) AGAINST(? IN BOOLEAN MODE)';
    $params[] = $q . '*';
}

// Tag filter (checks comma-separated tags column)
if ($tag !== '') {
    $where[]  = 'FIND_IN_SET(?, REPLACE(r.tags, ", ", ","))';
    $params[] = $tag;
}

// Category
if ($category !== '') {
    $where[]  = 'r.category = ?';
    $params[] = $category;
}

// Minimum rating
if ($minRating > 0) {
    $where[]  = 'r.avg_rating >= ?';
    $params[] = $minRating;
}

// Difficulty
if (in_array($difficulty, ['Easy', 'Medium', 'Hard'])) {
    $where[]  = 'r.difficulty = ?';
    $params[] = $difficulty;
}

// Max total time
if ($maxTime > 0) {
    $where[]  = '(r.prep_time + r.cook_time) <= ?';
    $params[] = $maxTime;
}

$whereSQL = 'WHERE ' . implode(' AND ', $where);

// ── ORDER BY ──────────────────────────────────────────────
$orderSQL = match ($sort) {
    'rating' => 'ORDER BY r.avg_rating DESC, r.review_count DESC',
    'time'   => 'ORDER BY (r.prep_time + r.cook_time) ASC',
    default  => 'ORDER BY r.created_at DESC',
};

// ── Count total matching rows ─────────────────────────────
$countSQL  = "SELECT COUNT(*) FROM recipes r $whereSQL";
$countStmt = db()->prepare($countSQL);
$countStmt->execute($params);
$total = (int) $countStmt->fetchColumn();
$pages = (int) ceil($total / $perPage);

// ── Fetch page ────────────────────────────────────────────
$offset  = ($page - 1) * $perPage;
$dataSQL = "
    SELECT
        r.id, r.title, r.description, r.category, r.tags,
        r.difficulty, r.prep_time, r.cook_time,
        r.avg_rating, r.review_count, r.created_at,
        u.username AS author, u.id AS author_id
    FROM recipes r
    JOIN users u ON u.id = r.user_id
    $whereSQL
    $orderSQL
    LIMIT ? OFFSET ?
";

$dataParams   = array_merge($params, [$perPage, $offset]);
$dataStmt     = db()->prepare($dataSQL);
$dataStmt->execute($dataParams);
$recipes = $dataStmt->fetchAll();

// Decode JSON fields for convenience
foreach ($recipes as &$rec) {
    $rec['total_time'] = ((int)$rec['prep_time']) + ((int)$rec['cook_time']);
    $rec['tags']       = $rec['tags'] ? array_map('trim', explode(',', $rec['tags'])) : [];
}

json_ok([
    'recipes'  => $recipes,
    'total'    => $total,
    'page'     => $page,
    'per_page' => $perPage,
    'pages'    => $pages,
    'query'    => [
        'q'          => $q,
        'tag'        => $tag,
        'category'   => $category,
        'min_rating' => $minRating,
        'difficulty' => $difficulty,
        'max_time'   => $maxTime,
        'sort'       => $sort,
    ],
]);
