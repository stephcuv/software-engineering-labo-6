<?php
// ─────────────────────────────────────────────────────────
//  helpers.php  –  shared utilities
// ─────────────────────────────────────────────────────────
require_once __DIR__ . '/config.php';
require_once __DIR__ . '/db.php';

// ── CORS + JSON headers ───────────────────────────────────
function send_headers(): void {
    header('Content-Type: application/json; charset=utf-8');
    header('Access-Control-Allow-Origin: '  . ALLOW_ORIGIN);
    header('Access-Control-Allow-Methods: GET, POST, PUT, DELETE, OPTIONS');
    header('Access-Control-Allow-Headers: Content-Type, Authorization');
    if ($_SERVER['REQUEST_METHOD'] === 'OPTIONS') {
        http_response_code(204);
        exit;
    }
}

// ── JSON response helpers ─────────────────────────────────
function json_ok(mixed $data, int $code = 200): never {
    http_response_code($code);
    echo json_encode(['success' => true,  'data'  => $data],  JSON_UNESCAPED_UNICODE);
    exit;
}

function json_err(string $message, int $code = 400): never {
    http_response_code($code);
    echo json_encode(['success' => false, 'error' => $message], JSON_UNESCAPED_UNICODE);
    exit;
}

// ── Read + validate JSON body ─────────────────────────────
function body(): array {
    $raw = file_get_contents('php://input');
    $data = json_decode($raw, true);
    return is_array($data) ? $data : [];
}

function require_fields(array $body, array $fields): void {
    foreach ($fields as $f) {
        if (!isset($body[$f]) || trim((string)$body[$f]) === '') {
            json_err("Missing required field: $f");
        }
    }
}

// ── Session / auth ────────────────────────────────────────

/**
 * Resolve the bearer token from the Authorization header.
 * Returns the matching user row, or null if invalid / expired.
 */
function resolve_user(): ?array {
    $header = $_SERVER['HTTP_AUTHORIZATION'] ?? '';
    if (!preg_match('/^Bearer\s+(\S+)$/i', $header, $m)) return null;
    $token = $m[1];

    $stmt = db()->prepare(
        'SELECT u.* FROM sessions s
         JOIN users u ON u.id = s.user_id
         WHERE s.token = ? AND s.expires_at > NOW() AND u.is_banned = 0'
    );
    $stmt->execute([$token]);
    return $stmt->fetch() ?: null;
}

/**
 * Require a valid session. Returns the user row.
 * Sends 401 and exits if not authenticated.
 */
function require_auth(): array {
    $user = resolve_user();
    if (!$user) json_err('Unauthorised – please log in.', 401);
    return $user;
}

/**
 * Require the authenticated user to have the 'admin' role.
 */
function require_admin(): array {
    $user = require_auth();
    if ($user['role'] !== 'admin') json_err('Forbidden – admins only.', 403);
    return $user;
}

// ── Input sanitisation ────────────────────────────────────
function sanitise(string $value, int $maxLen = 255): string {
    return mb_substr(trim(strip_tags($value)), 0, $maxLen);
}
