<?php
// ─────────────────────────────────────────────────────────
//  api/moderation.php  –  Admin moderation queue
//
//  GET  /api/moderation.php                – list pending recipes
//  POST /api/moderation.php?id=N&action=approve
//  POST /api/moderation.php?id=N&action=reject
//  POST /api/moderation.php?action=ban&user_id=N
//  POST /api/moderation.php?action=unban&user_id=N
//
//  All routes require admin role.
// ─────────────────────────────────────────────────────────
require_once __DIR__ . '/../helpers.php';

send_headers();

$method = $_SERVER['REQUEST_METHOD'];
$action = $_GET['action'] ?? '';
$id     = isset($_GET['id']) ? (int)$_GET['id'] : null;

match (true) {
    $method === 'GET'                               => list_pending(),
    $method === 'POST' && $action === 'approve'     => moderate_recipe($id, 'published'),
    $method === 'POST' && $action === 'reject'      => moderate_recipe($id, 'rejected'),
    $method === 'POST' && $action === 'ban'         => ban_user((int)($_GET['user_id'] ?? 0), 1),
    $method === 'POST' && $action === 'unban'       => ban_user((int)($_GET['user_id'] ?? 0), 0),
    default                                         => json_err('Invalid route.', 404),
};

function list_pending(): never {
    require_admin();
    $stmt = db()->prepare('
        SELECT r.id, r.title, r.category, r.difficulty,
               r.prep_time, r.cook_time, r.created_at,
               u.username AS author, u.email AS author_email
        FROM recipes r JOIN users u ON u.id = r.user_id
        WHERE r.status = "pending"
        ORDER BY r.created_at ASC
    ');
    $stmt->execute();
    json_ok($stmt->fetchAll());
}

function moderate_recipe(?int $id, string $status): never {
    require_admin();
    if (!$id) json_err('Recipe id required.');

    $stmt = db()->prepare('SELECT id FROM recipes WHERE id = ? AND status = "pending"');
    $stmt->execute([$id]);
    if (!$stmt->fetch()) json_err('Pending recipe not found.', 404);

    db()->prepare('UPDATE recipes SET status = ? WHERE id = ?')->execute([$status, $id]);
    json_ok(['message' => "Recipe $status."]);
}

function ban_user(int $userId, int $banned): never {
    require_admin();
    if (!$userId) json_err('user_id required.');

    $stmt = db()->prepare('SELECT id FROM users WHERE id = ? AND role != "admin"');
    $stmt->execute([$userId]);
    if (!$stmt->fetch()) json_err('User not found or cannot ban an admin.', 404);

    db()->prepare('UPDATE users SET is_banned = ? WHERE id = ?')->execute([$banned, $userId]);
    $msg = $banned ? 'User banned.' : 'User unbanned.';
    json_ok(['message' => $msg]);
}
