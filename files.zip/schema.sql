-- RecipeShare Database Schema
-- Run this file once to set up the database:
-- mysql -u root -p < schema.sql

CREATE DATABASE IF NOT EXISTS recipeshare CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;
USE recipeshare;

-- ─── USERS ───────────────────────────────────────────────
CREATE TABLE IF NOT EXISTS users (
    id          INT AUTO_INCREMENT PRIMARY KEY,
    username    VARCHAR(50)  NOT NULL UNIQUE,
    email       VARCHAR(255) NOT NULL UNIQUE,
    password    VARCHAR(255) NOT NULL,          -- bcrypt hash
    role        ENUM('user','admin') NOT NULL DEFAULT 'user',
    is_banned   TINYINT(1)   NOT NULL DEFAULT 0,
    created_at  DATETIME     NOT NULL DEFAULT CURRENT_TIMESTAMP
);

-- ─── SESSIONS ────────────────────────────────────────────
CREATE TABLE IF NOT EXISTS sessions (
    token       VARCHAR(64)  NOT NULL PRIMARY KEY,
    user_id     INT          NOT NULL,
    expires_at  DATETIME     NOT NULL,
    created_at  DATETIME     NOT NULL DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE
);

-- ─── RECIPES ─────────────────────────────────────────────
CREATE TABLE IF NOT EXISTS recipes (
    id           INT AUTO_INCREMENT PRIMARY KEY,
    user_id      INT          NOT NULL,
    title        VARCHAR(255) NOT NULL,
    description  TEXT,
    ingredients  TEXT         NOT NULL,          -- JSON array
    steps        TEXT         NOT NULL,          -- JSON array
    category     VARCHAR(100),
    tags         VARCHAR(500),                   -- comma-separated
    prep_time    INT,                            -- minutes
    cook_time    INT,                            -- minutes
    difficulty   ENUM('Easy','Medium','Hard') DEFAULT 'Easy',
    status       ENUM('pending','published','rejected') NOT NULL DEFAULT 'pending',
    avg_rating   DECIMAL(3,2) DEFAULT 0.00,
    review_count INT          NOT NULL DEFAULT 0,
    created_at   DATETIME     NOT NULL DEFAULT CURRENT_TIMESTAMP,
    updated_at   DATETIME     NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE,
    FULLTEXT INDEX ft_search (title, description, tags)
);

-- ─── REVIEWS ─────────────────────────────────────────────
CREATE TABLE IF NOT EXISTS reviews (
    id         INT AUTO_INCREMENT PRIMARY KEY,
    recipe_id  INT  NOT NULL,
    user_id    INT  NOT NULL,
    rating     TINYINT NOT NULL CHECK (rating BETWEEN 1 AND 5),
    body       TEXT,
    created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (recipe_id) REFERENCES recipes(id) ON DELETE CASCADE,
    FOREIGN KEY (user_id)   REFERENCES users(id)   ON DELETE CASCADE,
    UNIQUE KEY one_review_per_user (recipe_id, user_id)
);

-- ─── SEED: demo admin user ───────────────────────────────
-- password: admin123  (bcrypt hash)
INSERT IGNORE INTO users (username, email, password, role)
VALUES ('admin', 'admin@recipeshare.local',
        '$2y$12$92IXUNpkjO0rOQ5byMi.Ye4oKoEa3Ro9llC/.og/at2.uXDO/u1iO', 'admin');
