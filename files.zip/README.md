# RecipeShare — PHP/MySQL Backend

## Stack
| Layer    | Technology           |
|----------|----------------------|
| Language | PHP 8.1+             |
| Database | MySQL 8.0+           |
| Auth     | Bearer token (custom sessions table) |
| Passwords| bcrypt (cost 12)     |

---

## 1. Requirements

- PHP 8.1+ with extensions: `pdo`, `pdo_mysql`, `json`
- MySQL 8.0+
- Apache 2.4+ with `mod_rewrite` (or Nginx — see note below)

---

## 2. Setup

### 2a. Database

```bash
mysql -u root -p < schema.sql
```

This creates the `recipeshare` database, all tables, and a seed admin user:

| Field    | Value              |
|----------|--------------------|
| Email    | admin@recipeshare.local |
| Password | admin123           |

> Change the admin password immediately after first login.

### 2b. Configuration

Edit `config.php` and set your database credentials:

```php
define('DB_HOST', 'localhost');
define('DB_NAME', 'recipeshare');
define('DB_USER', 'your_db_user');
define('DB_PASS', 'your_db_password');
```

For production, also set:
```php
define('ALLOW_ORIGIN', 'https://your-frontend.com');
```

### 2c. File Structure

Place the `backend/` folder inside your web root (e.g. `htdocs/` or `/var/www/html/`):

```
backend/
├── .htaccess
├── config.php
├── db.php
├── helpers.php
├── schema.sql
└── api/
    ├── auth.php
    ├── recipes.php
    ├── search.php
    └── moderation.php
```

---

## 3. API Reference

All endpoints return JSON: `{ "success": true/false, "data": ... }` or `{ "success": false, "error": "..." }`.

Authentication uses a **Bearer token** in the `Authorization` header:
```
Authorization: Bearer <token>
```

---

### Auth  `/api/auth.php`

#### POST `?action=register`
```json
{
  "username": "HomeChef_Jen",
  "email": "jen@example.com",
  "password": "securepassword"
}
```
Returns: `{ token, user }`

---

#### POST `?action=login`
```json
{
  "email": "jen@example.com",
  "password": "securepassword"
}
```
Returns: `{ token, user }`

---

#### POST `?action=logout`  🔒
Invalidates the current token.

---

#### GET `?action=me`  🔒
Returns the authenticated user's profile.

---

### Recipes  `/api/recipes.php`

#### GET (no id)
List published recipes.  
Query params: `page`, `per_page`

#### GET `?id=N`
Single recipe with full ingredients, steps, and 20 most recent reviews.

#### POST  🔒
Create a recipe (status set to `pending` for moderation).
```json
{
  "title": "Creamy Pesto Pasta",
  "description": "A quick weeknight classic.",
  "ingredients": ["300g linguine", "4 tbsp pesto", "100ml cream"],
  "steps": [
    { "title": "Cook pasta", "text": "Boil in salted water." },
    { "title": "Make sauce", "text": "Warm pesto with cream." }
  ],
  "category": "Pasta",
  "tags": "quick, vegetarian",
  "difficulty": "Easy",
  "prep_time": 5,
  "cook_time": 15
}
```

#### PUT `?id=N`  🔒
Update a recipe (owner or admin). Any changed fields only.  
Owner's recipe is re-submitted for moderation.

#### DELETE `?id=N`  🔒
Delete a recipe (owner or admin).

---

### Search  `/api/search.php`

#### GET
```
/api/search.php?q=pasta&tag=vegan&min_rating=4&difficulty=Easy&max_time=30&sort=rating&page=1
```

| Param       | Type   | Description                            |
|-------------|--------|----------------------------------------|
| `q`         | string | Full-text search (title, desc, tags)   |
| `tag`       | string | Exact tag match                        |
| `category`  | string | Exact category match                   |
| `min_rating`| float  | Minimum average rating (1–5)           |
| `difficulty`| string | Easy / Medium / Hard                   |
| `max_time`  | int    | Max prep+cook time in minutes          |
| `sort`      | string | `newest` (default) / `rating` / `time`|
| `page`      | int    | Page number                            |
| `per_page`  | int    | Results per page (max 50)              |

Returns: `{ recipes[], total, page, per_page, pages, query }`

---

### Moderation  `/api/moderation.php`  🔒 Admin only

#### GET
List all `pending` recipes.

#### POST `?action=approve&id=N`
Publish a recipe.

#### POST `?action=reject&id=N`
Reject a recipe.

#### POST `?action=ban&user_id=N`
Ban a user account.

#### POST `?action=unban&user_id=N`
Restore a banned user account.

---

## 4. Connecting the Frontend

In your `recipe-platform.html`, replace the hardcoded recipe array with live API calls. Example:

```javascript
// Search
const res = await fetch('/backend/api/search.php?q=pasta&sort=rating');
const { data } = await res.json();
renderGrid('search-grid', data.recipes);

// Login
const res = await fetch('/backend/api/auth.php?action=login', {
  method: 'POST',
  headers: { 'Content-Type': 'application/json' },
  body: JSON.stringify({ email, password })
});
const { data } = await res.json();
localStorage.setItem('token', data.token);

// Authenticated request
const res = await fetch('/backend/api/recipes.php', {
  method: 'POST',
  headers: {
    'Content-Type': 'application/json',
    'Authorization': 'Bearer ' + localStorage.getItem('token')
  },
  body: JSON.stringify(recipeData)
});
```

---

## 5. Security Checklist (before going live)

- [ ] Change `DB_PASS` and `ALLOW_ORIGIN` in `config.php`
- [ ] Change the seed admin password
- [ ] Enable HTTPS and uncomment the redirect in `.htaccess`
- [ ] Set `display_errors = Off` in `php.ini`
- [ ] Run the app behind a firewall; restrict MySQL to `localhost`
- [ ] Schedule daily `mysqldump` backups
