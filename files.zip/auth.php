<?php
// ─────────────────────────────────────────────────────────
//  api/auth.php
//
//  POST /api/auth.php?action=register
//  POST /api/auth.php?action=login
//  POST /api/auth.php?action=logout      (requires token)
//  GET  /api/auth.php?action=me          (requires token)
// ─────────────────────────────────────────────────────────
require_once __DIR__ . '/../helpers.php';

send_headers();

$action = $_GET['action'] ?? '';

match ($action) {
    'register' => handle_register(),
    'login'    => handle_login(),
    'logout'   => handle_logout(),
    'me'       => handle_me(),
    default    => json_err("Unknown action '$action'.", 404),
};

// ── Register ──────────────────────────────────────────────
function handle_register(): never {
    $b = body();
    require_fields($b, ['username', 'email', 'password']);

    $username = sanitise($b['username'], 50);
    $email    = filter_var(trim($b['email']), FILTER_VALIDATE_EMAIL);
    $password = $b['password'];

    if (!$email)               json_err('Invalid email address.');
    if (strlen($password) < 8) json_err('Password must be at least 8 characters.');

    // Duplicate check
    $stmt = db()->prepare('SELECT id FROM users WHERE email = ? OR username = ? LIMIT 1');
    $stmt->execute([$email, $username]);
    if ($stmt->fetch()) json_err('Email or username already taken.');

    $hash = password_hash($password, PASSWORD_BCRYPT, ['cost' => BCRYPT_COST]);
    $ins  = db()->prepare('INSERT INTO users (username, email, password) VALUES (?, ?, ?)');
    $ins->execute([$username, $email, $hash]);
    $userId = (int) db()->lastInsertId();

    $token = create_session($userId);
    json_ok(['token' => $token, 'user' => public_user($userId)], 201);
}

// ── Login ─────────────────────────────────────────────────
function handle_login(): never {
    $b = body();
    require_fields($b, ['email', 'password']);

    $email    = trim($b['email']);
    $password = $b['password'];

    $stmt = db()->prepare('SELECT * FROM users WHERE email = ? LIMIT 1');
    $stmt->execute([$email]);
    $user = $stmt->fetch();

    if (!$user || !password_verify($password, $user['password'])) {
        json_err('Invalid email or password.', 401);
    }
    if ($user['is_banned']) {
        json_err('This account has been suspended.', 403);
    }

    $token = create_session((int) $user['id']);
    json_ok(['token' => $token, 'user' => strip_sensitive($user)]);
}

// ── Logout ────────────────────────────────────────────────
function handle_logout(): never {
    require_auth();
    $header = $_SERVER['HTTP_AUTHORIZATION'] ?? '';
    preg_match('/^Bearer\s+(\S+)$/i', $header, $m);
    $token = $m[1] ?? '';

    db()->prepare('DELETE FROM sessions WHERE token = ?')->execute([$token]);
    json_ok(['message' => 'Logged out successfully.']);
}

// ── Me ────────────────────────────────────────────────────
function handle_me(): never {
    $user = require_auth();
    json_ok(strip_sensitive($user));
}

// ── Helpers ───────────────────────────────────────────────

function create_session(int $userId): string {
    $token   = bin2hex(random_bytes(32));
    $expires = date('Y-m-d H:i:s', time() + SESSION_TTL_HOURS * 3600);
    db()->prepare('INSERT INTO sessions (token, user_id, expires_at) VALUES (?, ?, ?)')
        ->execute([$token, $userId, $expires]);
    return $token;
}

function public_user(int $id): array {
    $stmt = db()->prepare('SELECT * FROM users WHERE id = ?');
    $stmt->execute([$id]);
    return strip_sensitive($stmt->fetch());
}

function strip_sensitive(array $user): array {
    unset($user['password']);
    return $user;
}
