<?php
// ─────────────────────────────────────────────────────────
//  api/recipes.php  –  Recipe CRUD
//
//  GET    /api/recipes.php          – list published recipes
//  GET    /api/recipes.php?id=N     – single recipe detail
//  POST   /api/recipes.php          – create  (auth required)
//  PUT    /api/recipes.php?id=N     – update  (owner or admin)
//  DELETE /api/recipes.php?id=N     – delete  (owner or admin)
// ─────────────────────────────────────────────────────────
require_once __DIR__ . '/../helpers.php';

send_headers();

$method = $_SERVER['REQUEST_METHOD'];
$id     = isset($_GET['id']) ? (int)$_GET['id'] : null;

match (true) {
    $method === 'GET'    && $id === null => list_recipes(),
    $method === 'GET'    && $id !== null => get_recipe($id),
    $method === 'POST'                   => create_recipe(),
    $method === 'PUT'    && $id !== null => update_recipe($id),
    $method === 'DELETE' && $id !== null => delete_recipe($id),
    default                              => json_err('Invalid route.', 404),
};

// ── LIST ──────────────────────────────────────────────────
function list_recipes(): never {
    $page    = max(1, (int)($_GET['page'] ?? 1));
    $perPage = min(50, max(1, (int)($_GET['per_page'] ?? DEFAULT_PAGE_SIZE)));
    $offset  = ($page - 1) * $perPage;

    $total = (int) db()->query('SELECT COUNT(*) FROM recipes WHERE status="published"')->fetchColumn();

    $stmt = db()->prepare('
        SELECT r.id, r.title, r.description, r.category, r.tags,
               r.difficulty, r.prep_time, r.cook_time,
               r.avg_rating, r.review_count, r.created_at,
               u.username AS author, u.id AS author_id
        FROM recipes r JOIN users u ON u.id = r.user_id
        WHERE r.status = "published"
        ORDER BY r.created_at DESC
        LIMIT ? OFFSET ?
    ');
    $stmt->execute([$perPage, $offset]);
    $recipes = $stmt->fetchAll();
    foreach ($recipes as &$r) decode_recipe($r);

    json_ok(['recipes' => $recipes, 'total' => $total, 'page' => $page, 'per_page' => $perPage]);
}

// ── SINGLE ────────────────────────────────────────────────
function get_recipe(int $id): never {
    $stmt = db()->prepare('
        SELECT r.*, u.username AS author, u.id AS author_id
        FROM recipes r JOIN users u ON u.id = r.user_id
        WHERE r.id = ? AND r.status = "published"
    ');
    $stmt->execute([$id]);
    $recipe = $stmt->fetch();
    if (!$recipe) json_err('Recipe not found.', 404);
    decode_recipe($recipe);

    // Attach reviews
    $rev = db()->prepare('
        SELECT rv.id, rv.rating, rv.body, rv.created_at, u.username
        FROM reviews rv JOIN users u ON u.id = rv.user_id
        WHERE rv.recipe_id = ?
        ORDER BY rv.created_at DESC LIMIT 20
    ');
    $rev->execute([$id]);
    $recipe['reviews'] = $rev->fetchAll();

    json_ok($recipe);
}

// ── CREATE ────────────────────────────────────────────────
function create_recipe(): never {
    $user = require_auth();
    $b    = body();
    require_fields($b, ['title', 'ingredients', 'steps']);

    $title       = sanitise($b['title'], 255);
    $description = sanitise($b['description'] ?? '', 2000);
    $category    = sanitise($b['category']    ?? '', 100);
    $tags        = sanitise($b['tags']        ?? '', 500);
    $difficulty  = in_array($b['difficulty'] ?? '', ['Easy','Medium','Hard'])
                   ? $b['difficulty'] : 'Easy';
    $prepTime    = max(0, (int)($b['prep_time'] ?? 0));
    $cookTime    = max(0, (int)($b['cook_time'] ?? 0));

    // Validate JSON arrays
    $ingredients = is_array($b['ingredients']) ? json_encode($b['ingredients']) : null;
    $steps       = is_array($b['steps'])       ? json_encode($b['steps'])       : null;
    if (!$ingredients) json_err('ingredients must be an array.');
    if (!$steps)       json_err('steps must be an array.');

    $stmt = db()->prepare('
        INSERT INTO recipes
            (user_id, title, description, ingredients, steps, category, tags,
             difficulty, prep_time, cook_time, status)
        VALUES (?,?,?,?,?,?,?,?,?,?,"pending")
    ');
    $stmt->execute([
        $user['id'], $title, $description, $ingredients, $steps,
        $category, $tags, $difficulty, $prepTime, $cookTime,
    ]);
    $newId = (int) db()->lastInsertId();
    json_ok(['id' => $newId, 'message' => 'Recipe submitted for moderation.'], 201);
}

// ── UPDATE ────────────────────────────────────────────────
function update_recipe(int $id): never {
    $user   = require_auth();
    $recipe = find_recipe_or_fail($id, true);   // include non-published

    if ($user['id'] !== (int)$recipe['user_id'] && $user['role'] !== 'admin') {
        json_err('Forbidden.', 403);
    }

    $b = body();
    $fields = []; $params = [];

    $allowed = ['title','description','category','tags','difficulty','prep_time','cook_time'];
    foreach ($allowed as $f) {
        if (isset($b[$f])) {
            $fields[] = "$f = ?";
            $params[] = in_array($f, ['prep_time','cook_time'])
                        ? max(0, (int)$b[$f])
                        : sanitise((string)$b[$f]);
        }
    }
    foreach (['ingredients','steps'] as $f) {
        if (isset($b[$f]) && is_array($b[$f])) {
            $fields[] = "$f = ?";
            $params[] = json_encode($b[$f]);
        }
    }
    if (empty($fields)) json_err('Nothing to update.');

    // Owners re-submit for moderation; admins keep current status
    if ($user['role'] !== 'admin') {
        $fields[] = 'status = "pending"';
    }

    $params[] = $id;
    db()->prepare('UPDATE recipes SET ' . implode(', ', $fields) . ' WHERE id = ?')
        ->execute($params);

    json_ok(['message' => 'Recipe updated.']);
}

// ── DELETE ────────────────────────────────────────────────
function delete_recipe(int $id): never {
    $user   = require_auth();
    $recipe = find_recipe_or_fail($id, true);

    if ($user['id'] !== (int)$recipe['user_id'] && $user['role'] !== 'admin') {
        json_err('Forbidden.', 403);
    }
    db()->prepare('DELETE FROM recipes WHERE id = ?')->execute([$id]);
    json_ok(['message' => 'Recipe deleted.']);
}

// ── Helpers ───────────────────────────────────────────────
function find_recipe_or_fail(int $id, bool $anyStatus = false): array {
    $extra = $anyStatus ? '' : 'AND status = "published"';
    $stmt  = db()->prepare("SELECT * FROM recipes WHERE id = ? $extra");
    $stmt->execute([$id]);
    $r = $stmt->fetch();
    if (!$r) json_err('Recipe not found.', 404);
    return $r;
}

function decode_recipe(array &$r): void {
    $r['ingredients'] = json_decode($r['ingredients'] ?? '[]', true) ?? [];
    $r['steps']       = json_decode($r['steps']       ?? '[]', true) ?? [];
    $r['tags']        = $r['tags'] ? array_map('trim', explode(',', $r['tags'])) : [];
    $r['total_time']  = ((int)$r['prep_time']) + ((int)$r['cook_time']);
}
